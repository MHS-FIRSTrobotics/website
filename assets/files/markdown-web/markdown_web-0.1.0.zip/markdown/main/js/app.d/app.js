
    var app = angular.module("markdown", ["ngSanitize", "ui.codemirror"]);

    app.controller('markdown-editor', ['$scope', function ($scope) {
        $scope.code = "# Hi";
        $scope.content = marked($scope.code);

        $scope.cmOptions = {
            mode: "markdown",
            value: "# Hi2",
            lineWrapping: true,
            lineNumbers: true,
            theme: "mdn-like"
        };

        $scope.$watch('code', function () {
            $scope.content = marked($scope.code);
        });
    }]);


