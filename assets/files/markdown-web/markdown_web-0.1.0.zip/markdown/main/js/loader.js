require.config({
    baseUrl: 'js',
    paths: {
        'jquery': 'vendor/jquery/jquery',
        'angular': 'vendor/angular/angular',
        'bootstrap': 'vendor/bootstrap/bootstrap',
        'codemirror': 'vendor/codemirror/codemirror',
        'marked': 'vendor/marked/marked',
        'app': 'app.d/app'//,
        //'uiCodemirror': 'vendor/angular/ui-codemirror'
    },

    shim: {
        'angular': {
            deps: ['jquery'],
            exports : 'angular'
        }, 'uiCodemirror': {
            deps: ['codemirror']
        }, 'bootstrap': {
            deps: ['jquery']
        }
    }
});

require(["bootstrap", "app"],
function() {
    console.log("Done!")
});
